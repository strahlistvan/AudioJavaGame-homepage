---
Title: Főoldal
Description: Az AudioJavaGame egy könnyen használható, szórakoztató Java alapú zenei kvízjáték. A játék a saját média állományaid felhasználásával tesz fel kérdéseket kedvenc zenéidről.
Robots: index, follow
---

##  AudioJavaGame - Platformfüggetlen zenei kvíz

<img src="%base_url%/img/disc.jpg" alt="Audio CD stock photo" align="left" style="margin: 10px">

%meta.description% <!-- replaced by the above Description meta header -->

A program lényegében egy zenei kvízjáték, ahol a kérdések a számítógépeden található zenéidről szólnak.
A program lejátszik egy zenerészletet, és meg kell válaszolnod a hallott zene címét, előadóját, 
megjelenésének dátumát, vagy éppen a zenét tartalmazó album címét.
A játék letöltése és használata teljesen ingyenes. A program Java platformra készült,
tehát egyaránt használható Windows, Macintosh és Linux alapú rendszereken is.
</p>

<hr />
<br />

<strong> A játék jelenleg négy játékmódot tartalmaz: </strong>
<ul>
	<li> "Mi a hallott zene címe?" </li>
	<li> "Ki az előadója a hallott zenének? </li>
	<li> "A hallott zene melyik albumon hallható?" </li>
	<li> "A hallott zene melyik évben jelent meg?" </li>
</ul>

Minden mód esetén 4-4 választás közül kell kitalálni a helyes választ. 
Ha sikerül, az 100 pontot ér.
Ha nem sikerül, egy életet veszít a játékos. 
Ha elfogytak az életek, a játék véget ér.

